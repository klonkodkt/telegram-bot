import logging
import sqlite3
from datetime import datetime
from typing import Optional, Dict

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes
)

# ========== НАСТРОЙКИ И КОНФИГУРАЦИЯ ==========
# ВАЖНО: ЗАПОЛНИТЕ ЭТИ ДАННЫЕ САМИ
BOT_TOKEN = "7971099053:AAHFJsN0KzHgnOWtmaC51_t54_9y8H344tg"  # ЗАПОЛНИТЬ
ADMIN_USER_ID = 8331396092  # ЗАПОЛНИТЬ: ваш Telegram ID
CHANNEL_USERNAME = "@PilotNFTNews"  # Имя канала для проверки подписки

# Целевое количество рефералов для получения NFT
NFT_REWARD_THRESHOLD = 20

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


# ========== БАЗА ДАННЫХ ==========
def init_db():
    """Инициализация базы данных SQLite"""
    conn = sqlite3.connect('referral_bot.db')
    cursor = conn.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        full_name TEXT,
        referrer_id INTEGER,
        join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_subscribed INTEGER DEFAULT 0,
        referral_count INTEGER DEFAULT 0,
        nft_reward_claimed INTEGER DEFAULT 0
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS referrals (
        referral_id INTEGER PRIMARY KEY AUTOINCREMENT,
        referrer_id INTEGER,
        referred_id INTEGER,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (referrer_id) REFERENCES users (user_id),
        FOREIGN KEY (referred_id) REFERENCES users (user_id)
    )
    ''')

    conn.commit()
    conn.close()
    logger.info("База данных инициализирована")


def get_user(user_id: int) -> Optional[Dict]:
    """Получение информации о пользователе"""
    conn = sqlite3.connect('referral_bot.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return dict(user) if user else None


def register_user(user_id: int, username: str, full_name: str, referrer_id: int = None):
    """Регистрация нового пользователя"""
    conn = sqlite3.connect('referral_bot.db')
    cursor = conn.cursor()

    existing_user = get_user(user_id)
    if existing_user:
        cursor.execute(
            "UPDATE users SET username = ?, full_name = ? WHERE user_id = ?",
            (username, full_name, user_id)
        )
    else:
        cursor.execute(
            """INSERT INTO users (user_id, username, full_name, referrer_id) 
               VALUES (?, ?, ?, ?)""",
            (user_id, username, full_name, referrer_id)
        )

        if referrer_id:
            cursor.execute(
                "UPDATE users SET referral_count = referral_count + 1 WHERE user_id = ?",
                (referrer_id,)
            )
            cursor.execute(
                """INSERT INTO referrals (referrer_id, referred_id) 
                   VALUES (?, ?)""",
                (referrer_id, user_id)
            )

    conn.commit()
    conn.close()


def update_subscription_status(user_id: int, is_subscribed: bool):
    """Обновление статуса подписки на канал"""
    conn = sqlite3.connect('referral_bot.db')
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE users SET is_subscribed = ? WHERE user_id = ?",
        (1 if is_subscribed else 0, user_id)
    )
    conn.commit()
    conn.close()


def get_referral_stats(user_id: int) -> Dict:
    """Получение статистики рефералов пользователя"""
    conn = sqlite3.connect('referral_bot.db')
    cursor = conn.cursor()

    user = get_user(user_id)
    if not user:
        return {"total": 0, "list": []}

    cursor.execute(
        """SELECT u.user_id, u.username, u.full_name, r.date 
           FROM referrals r 
           JOIN users u ON r.referred_id = u.user_id 
           WHERE r.referrer_id = ? 
           ORDER BY r.date DESC""",
        (user_id,)
    )
    referrals = cursor.fetchall()

    referrer_info = None
    if user.get('referrer_id'):
        referrer = get_user(user['referrer_id'])
        if referrer:
            referrer_info = {
                'user_id': referrer['user_id'],
                'username': referrer.get('username'),
                'full_name': referrer.get('full_name')
            }

    conn.close()

    return {
        "total": user.get('referral_count', 0),
        "list": referrals,
        "referrer": referrer_info,
        "nft_eligible": user.get('referral_count', 0) >= NFT_REWARD_THRESHOLD,
        "nft_claimed": bool(user.get('nft_reward_claimed', 0))
    }


def claim_nft_reward(user_id: int):
    """Отметка, что пользователь получил NFT награду"""
    conn = sqlite3.connect('referral_bot.db')
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE users SET nft_reward_claimed = 1 WHERE user_id = ?",
        (user_id,)
    )
    conn.commit()
    conn.close()


def get_all_users():
    """Получение списка всех пользователей"""
    conn = sqlite3.connect('referral_bot.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users ORDER BY join_date DESC")
    users = cursor.fetchall()
    conn.close()
    return [dict(user) for user in users]


def delete_user(user_id: int):
    """Удаление пользователя из базы данных"""
    conn = sqlite3.connect('referral_bot.db')
    cursor = conn.cursor()

    # Удаляем реферальные связи
    cursor.execute("DELETE FROM referrals WHERE referrer_id = ? OR referred_id = ?", (user_id, user_id))
    # Удаляем пользователя
    cursor.execute("DELETE FROM users WHERE user_id = ?", (user_id,))

    conn.commit()
    conn.close()


def get_admin_stats():
    """Получение статистики для админа"""
    conn = sqlite3.connect('referral_bot.db')
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM users")
    total_users = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM users WHERE is_subscribed = 1")
    subscribed_users = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM referrals")
    total_referrals = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM users WHERE referral_count >= ?", (NFT_REWARD_THRESHOLD,))
    eligible_for_nft = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM users WHERE nft_reward_claimed = 1")
    nft_claimed = cursor.fetchone()[0]

    cursor.execute('''
        SELECT u.user_id, u.username, u.full_name, u.referral_count
        FROM users u
        WHERE u.referral_count > 0
        ORDER BY u.referral_count DESC
        LIMIT 10
    ''')
    top_referrers = cursor.fetchall()

    conn.close()

    return {
        "total_users": total_users,
        "subscribed_users": subscribed_users,
        "total_referrals": total_referrals,
        "eligible_for_nft": eligible_for_nft,
        "nft_claimed": nft_claimed,
        "top_referrers": top_referrers
    }


# ========== ПРОВЕРКА ПОДПИСКИ НА КАНАЛ ==========
async def check_channel_subscription(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Проверка, подписан ли пользователь на канал"""
    try:
        chat_member = await context.bot.get_chat_member(
            chat_id=CHANNEL_USERNAME,
            user_id=user_id
        )
        subscribed_statuses = ['member', 'administrator', 'creator']
        return chat_member.status in subscribed_statuses
    except Exception as e:
        logger.error(f"Ошибка при проверке подписки для {user_id}: {e}")
        return False


# ========== КЛАВИАТУРЫ ==========
def get_main_menu_keyboard():
    """Клавиатура главного меню"""
    keyboard = [
        [InlineKeyboardButton("👤 Мой профиль", callback_data="profile")],
        [InlineKeyboardButton("🔗 Реферальная ссылка", callback_data="referral_link")],
        [InlineKeyboardButton("ℹ️ О боте", callback_data="about")],
        [InlineKeyboardButton("🎁 Получить NFT подарок", callback_data="claim_nft")],
        [InlineKeyboardButton("⚙️ Админ-панель", callback_data="admin_panel")]
    ]
    return InlineKeyboardMarkup(keyboard)


def get_back_keyboard(back_to="main_menu"):
    """Клавиатура с кнопкой 'Назад'"""
    keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data=back_to)]]
    return InlineKeyboardMarkup(keyboard)


def get_subscription_check_keyboard():
    """Клавиатура для проверки подписки"""
    keyboard = [
        [InlineKeyboardButton("📢 Подписаться на канал", url=f"https://t.me/{CHANNEL_USERNAME.strip('@')}")],
        [InlineKeyboardButton("✅ Я подписался", callback_data="check_subscription")]
    ]
    return InlineKeyboardMarkup(keyboard)


def get_admin_panel_keyboard():
    """Клавиатура админ-панели"""
    keyboard = [
        [InlineKeyboardButton("📊 Статистика бота", callback_data="admin_stats")],
        [InlineKeyboardButton("👥 Список пользователей", callback_data="admin_users")],
        [InlineKeyboardButton("🗑️ Удалить пользователя", callback_data="admin_delete_user")],
        [InlineKeyboardButton("🔙 В главное меню", callback_data="main_menu")]
    ]
    return InlineKeyboardMarkup(keyboard)


def get_admin_back_keyboard():
    """Кнопка назад в админ-панель"""
    keyboard = [[InlineKeyboardButton("🔙 В админ-панель", callback_data="admin_panel")]]
    return InlineKeyboardMarkup(keyboard)


# ========== ОБРАБОТЧИКИ КОМАНД ==========
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start"""
    user = update.effective_user
    referrer_id = None

    if context.args and context.args[0].isdigit():
        referrer_id = int(context.args[0])

    register_user(user.id, user.username, user.full_name, referrer_id)

    is_subscribed = await check_channel_subscription(user.id, context)

    if not is_subscribed:
        welcome_text = (
            f"👋 Привет, {user.full_name}!\n\n"
            f"📢 **Для использования бота необходимо подписаться на наш канал:**\n"
            f"{CHANNEL_USERNAME}\n\n"
            f"После подписки нажмите кнопку '✅ Я подписался'"
        )

        await update.message.reply_text(
            welcome_text,
            reply_markup=get_subscription_check_keyboard(),
            parse_mode='Markdown'
        )
        return

    await show_main_menu(update, context)


async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, message_text: str = None):
    """Показ главного меню"""
    if message_text is None:
        message_text = (
            "🤖 **Добро пожаловать в бот для заработка на рефералах!**\n\n"
            "🎯 **Как зарабатывать:**\n"
            "1. Приглашайте друзей по своей реферальной ссылке\n"
            "2. Каждый приглашенный друг увеличивает ваш счетчик\n"
            "3. Приведите 20 друзей и получите **NFT подарок**!\n\n"
            "👇 Выберите действие в меню ниже:"
        )

    keyboard = get_main_menu_keyboard()

    if update.callback_query:
        await update.callback_query.edit_message_text(
            message_text,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
    else:
        await update.message.reply_text(
            message_text,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик нажатий на кнопки"""
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id

    # Проверяем подписку перед выполнением действий
    is_subscribed = await check_channel_subscription(user_id, context)
    if not is_subscribed:
        await query.edit_message_text(
            "❌ Вы не подписаны на канал!\n\n"
            f"Подпишитесь на {CHANNEL_USERNAME} чтобы продолжить.",
            reply_markup=get_subscription_check_keyboard()
        )
        return

    # Обрабатываем разные кнопки
    if query.data == "profile":
        await show_profile(update, context)
    elif query.data == "referral_link":
        await show_referral_link(update, context)
    elif query.data == "about":
        await show_about(update, context)
    elif query.data == "claim_nft":
        await handle_nft_claim(update, context)
    elif query.data == "check_subscription":
        await handle_subscription_check(update, context)
    elif query.data == "main_menu":
        await show_main_menu(update, context)
    elif query.data == "admin_panel":
        await show_admin_panel(update, context)
    elif query.data == "admin_stats":
        await show_admin_stats(update, context)
    elif query.data == "admin_users":
        await show_admin_users(update, context)
    elif query.data == "admin_delete_user":
        await admin_delete_user_start(update, context)
    elif query.data == "show_stats_for_nft":
        await show_stats_for_nft(update, context)


# ========== ФУНКЦИИ ПОЛЬЗОВАТЕЛЯ ==========
async def show_profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ профиля пользователя"""
    query = update.callback_query
    user_id = query.from_user.id

    # Получаем данные пользователя
    user = get_user(user_id)
    stats = get_referral_stats(user_id)

    # Форматируем список рефералов
    referrals_list = ""
    if stats['list']:
        for i, ref in enumerate(stats['list'][:10], 1):  # Показываем первые 10
            ref_id, ref_username, ref_name, ref_date = ref
            username = f"@{ref_username}" if ref_username else ref_name or f"ID: {ref_id}"
            # Экранируем специальные символы
            safe_username = username.replace('*', '✱').replace('_', '＿').replace('`', 'ˋ')
            referrals_list += f"{i}. {safe_username} - {ref_date[:10]}\n"

    # Информация о реферере (кто пригласил)
    referrer_info = ""
    if stats['referrer']:
        ref = stats['referrer']
        ref_name = f"@{ref['username']}" if ref['username'] else ref['full_name']
        # Экранируем специальные символы
        safe_ref_name = ref_name.replace('*', '✱').replace('_', '＿').replace('`', 'ˋ')
        referrer_info = f"👤 Вас пригласил: {safe_ref_name}\n"

    # Статус NFT
    nft_status = ""
    if stats['nft_eligible']:
        if stats['nft_claimed']:
            nft_status = "✅ NFT подарок: Уже получен!\n"
        else:
            nft_status = "🎁 NFT подарок: Доступен для получения!\n"
    else:
        needed = NFT_REWARD_THRESHOLD - stats['total']
        nft_status = f"🎯 До NFT подарка: {needed} из {NFT_REWARD_THRESHOLD} рефералов\n"

    # Экранируем данные пользователя
    safe_full_name = user.get('full_name', 'Не указано').replace('*', '✱').replace('_', '＿').replace('`', 'ˋ')
    safe_username = user.get('username', 'не указан')
    if safe_username:
        safe_username = f"@{safe_username}".replace('*', '✱').replace('_', '＿').replace('`', 'ˋ')
    else:
        safe_username = "не указан"

    # Формируем текст профиля БЕЗ markdown разметки
    profile_text = (
        f"👤 Ваш профиль\n\n"
        f"🆔 ID: {user_id}\n"
        f"📛 Имя: {safe_full_name}\n"
        f"📱 Username: {safe_username}\n"
        f"📅 Дата регистрации: {user.get('join_date', '')[:10]}\n\n"
    )

    # Добавляем информацию о реферере, если есть
    if referrer_info:
        profile_text += f"{referrer_info}\n"

    # Добавляем статистику
    profile_text += (
        f"📊 Реферальная статистика:\n"
        f"👥 Всего приглашено: {stats['total']} человек\n\n"
        f"{nft_status}\n"
    )

    # Добавляем список рефералов, если они есть
    if referrals_list:
        profile_text += f"📋 Последние рефералы:\n{referrals_list}"

    await query.edit_message_text(
        profile_text,
        reply_markup=get_back_keyboard()
        # Убираем parse_mode='Markdown' для устранения ошибки
    )

    if referrals_list:
        profile_text += f"📋 **Последние рефералы:**\n{referrals_list}"

    await query.edit_message_text(
        profile_text,
        reply_markup=get_back_keyboard(),
        parse_mode='Markdown'
    )


async def show_referral_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ реферальной ссылки пользователя"""
    query = update.callback_query
    user_id = query.from_user.id

    bot_username = (await context.bot.get_me()).username
    referral_link = f"https://t.me/{bot_username}?start={user_id}"

    referral_text = (
        "🔗 **Ваша реферальная ссылка:**\n\n"
        f"`{referral_link}`\n\n"
        "**📢 Как использовать:**\n"
        "1. Поделитесь этой ссылкой с друзьями\n"
        "2. Каждый, кто перейдет по ней и нажмет /start, станет вашим рефералом\n"
        "3. Следите за статистикой в разделе '👤 Мой профиль'\n\n"
        "🎯 **Цель:** Пригласите 20 друзей и получите NFT подарок!"
    )

    await query.edit_message_text(
        referral_text,
        reply_markup=get_back_keyboard(),
        parse_mode='Markdown'
    )


async def show_about(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ информации о боте"""
    query = update.callback_query

    about_text = (
        "🤖 **О нашем боте**\n\n"
        "Это бот для заработка на реферальной программе!\n\n"
        "🎯 **Как это работает:**\n"
        "1. Вы получаете персональную реферальную ссылку\n"
        "2. Делитесь ей с друзьями в соцсетях\n"
        "3. Каждый друг, который присоединится по вашей ссылке, становится вашим рефералом\n"
        "4. Следите за своим прогрессом в профиле\n\n"
        "🏆 **Награда:**\n"
        "Тот, кто приведет **20 рефералов**, получит **эксклюзивный NFT подарок**!\n\n"
        "📢 **Обязательное условие:**\n"
        "Все участники должны быть подписаны на наш канал новостей:\n"
        f"{CHANNEL_USERNAME}\n\n"
        "📞 **Отчет о работе:** @Pilotcode"
    )

    await query.edit_message_text(
        about_text,
        reply_markup=get_back_keyboard(),
        parse_mode='Markdown'
    )


async def handle_nft_claim(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка запроса на получение NFT"""
    query = update.callback_query
    user_id = query.from_user.id

    stats = get_referral_stats(user_id)

    if not stats['nft_eligible']:
        needed = NFT_REWARD_THRESHOLD - stats['total']
        nft_text = (
            "❌ **Недостаточно рефералов!**\n\n"
            f"У вас {stats['total']} из {NFT_REWARD_THRESHOLD} необходимых рефералов.\n"
            f"Пригласите еще {needed} человек(а) для получения NFT подарка.\n\n"
            "📢 Продолжайте делиться реферальной ссылкой!"
        )
        await query.edit_message_text(
            nft_text,
            reply_markup=get_back_keyboard(),
            parse_mode='Markdown'
        )
        return

    if stats['nft_claimed']:
        nft_text = (
            "✅ **NFT подарок уже получен!**\n\n"
            "Вы уже получили свой NFT подарок за приглашение 20 рефералов.\n"
            "Спасибо за активное участие в нашей программе!"
        )
        await query.edit_message_text(
            nft_text,
            reply_markup=get_back_keyboard(),
            parse_mode='Markdown'
        )
        return

    nft_text = (
        "🎁 **Получение NFT подарка**\n\n"
        "Поздравляем! Вы пригласили 20 рефералов и имеете право на NFT подарок.\n\n"
        "📋 **Для получения подарка:**\n"
        "1. Нажмите кнопку '📊 Показать статистику' ниже\n"
        "2. Скопируйте сообщение со своей статистикой\n"
        "3. Отправьте его администратору: @Pilotcode\n\n"
        "После проверки администратор выдаст вам NFT подарок."
    )

    keyboard = [
        [InlineKeyboardButton("📊 Показать статистику", callback_data="show_stats_for_nft")],
        [InlineKeyboardButton("🔙 Назад", callback_data="main_menu")]
    ]

    await query.edit_message_text(
        nft_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )


async def handle_subscription_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверка подписки пользователя на канал"""
    query = update.callback_query
    user_id = query.from_user.id

    is_subscribed = await check_channel_subscription(user_id, context)

    if is_subscribed:
        update_subscription_status(user_id, True)
        await show_main_menu(update, context,
                             "✅ **Отлично! Вы подписаны на канал.**\n\nТеперь вы можете пользоваться ботом.")
    else:
        await query.edit_message_text(
            "❌ **Вы все еще не подписаны на канал!**\n\n"
            f"1. Перейдите в канал: {CHANNEL_USERNAME}\n"
            "2. Нажмите кнопку 'Присоединиться' или 'Join'\n"
            "3. Вернитесь сюда и нажмите '✅ Я подписался' еще раз",
            reply_markup=get_subscription_check_keyboard()
        )


async def show_stats_for_nft(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ статистики для отправки администратору"""
    query = update.callback_query
    user_id = query.from_user.id

    user = get_user(user_id)
    stats = get_referral_stats(user_id)

    stats_text = (
        "📊 **Статистика для получения NFT:**\n\n"
        f"👤 **Пользователь:** {user.get('full_name', 'Не указано')}\n"
        f"🆔 **User ID:** {user_id}\n"
        f"📱 **Username:** @{user.get('username', 'не указан')}\n"
        f"📅 **Дата регистрации:** {user.get('join_date', '')[:10]}\n\n"
        f"📈 **Реферальная статистика:**\n"
        f"✅ **Всего рефералов:** {stats['total']}\n"
        f"🎯 **Требуется для NFT:** {NFT_REWARD_THRESHOLD}\n"
        f"🏆 **Статус:** {'Доступен NFT подарок' if stats['nft_eligible'] else 'Недостаточно рефералов'}\n\n"
        f"📝 **Последние рефералы (первые 5):**\n"
    )

    if stats['list']:
        for i, ref in enumerate(stats['list'][:5], 1):
            ref_id, ref_username, ref_name, ref_date = ref
            username = f"@{ref_username}" if ref_username else ref_name or f"ID: {ref_id}"
            stats_text += f"{i}. {username} - {ref_date[:10]}\n"
    else:
        stats_text += "Нет рефералов\n"

    stats_text += f"\n📅 **Отчет сформирован:** {datetime.now().strftime('%Y-%m-%d %H:%M')}"

    keyboard = [
        [InlineKeyboardButton("✉️ Отправить администратору", url=f"https://t.me/Pilotcode")],
        [InlineKeyboardButton("🔙 Назад к NFT", callback_data="claim_nft")],
        [InlineKeyboardButton("🏠 В главное меню", callback_data="main_menu")]
    ]

    await query.edit_message_text(
        stats_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='Markdown'
    )


# ========== АДМИН-ПАНЕЛЬ ==========
def is_admin(user_id: int) -> bool:
    """Проверка, является ли пользователь администратором"""
    return user_id == ADMIN_USER_ID


async def show_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ админ-панели"""
    query = update.callback_query
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.edit_message_text("❌ Доступ запрещен. Вы не администратор.")
        return

    admin_text = (
        "⚙️ **Админ-панель**\n\n"
        "Выберите действие:"
    )

    await query.edit_message_text(
        admin_text,
        reply_markup=get_admin_panel_keyboard(),
        parse_mode='Markdown'
    )


async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ статистики для админа"""
    query = update.callback_query
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.edit_message_text("❌ Доступ запрещен.")
        return

    stats = get_admin_stats()

    stats_text = (
        "📊 **Статистика бота:**\n\n"
        f"👥 **Всего пользователей:** {stats['total_users']}\n"
        f"✅ **Подписано на канал:** {stats['subscribed_users']}\n"
        f"🔗 **Всего реферальных переходов:** {stats['total_referrals']}\n"
        f"🎁 **Доступно NFT:** {stats['eligible_for_nft']} пользователей\n"
        f"✅ **Получили NFT:** {stats['nft_claimed']} пользователей\n\n"
        "🏆 **Топ-10 рефереров:**\n"
    )

    for i, (ref_id, username, full_name, count) in enumerate(stats['top_referrers'], 1):
        name = f"@{username}" if username else full_name or f"ID: {ref_id}"
        stats_text += f"{i}. {name} - {count} рефералов\n"

    await query.edit_message_text(
        stats_text,
        reply_markup=get_admin_back_keyboard(),
        parse_mode='Markdown'
    )


async def show_admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показ списка пользователей"""
    query = update.callback_query
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.edit_message_text("❌ Доступ запрещен.")
        return

    users = get_all_users()

    if not users:
        users_text = "👥 Пользователей не найдено"
    else:
        users_text = "👥 <b>Список пользователей:</b>\n\n"
        for i, user in enumerate(users[:20], 1):  # Показываем первые 20
            user_id_val = user['user_id']
            username = f"@{user['username']}" if user['username'] else "нет"
            full_name = user['full_name'] or "Не указано"
            subs = "✅" if user['is_subscribed'] else "❌"
            refs = user['referral_count']
            nft = "🎁" if user['nft_reward_claimed'] else "⏳"

            # Добавляем номер пользователя
            users_text += f"<b>{i}. Пользователь #{user_id_val}</b>\n"
            users_text += f"├ <b>Имя:</b> {full_name}\n"
            users_text += f"├ <b>Username:</b> {username}\n"
            users_text += f"├ <b>Подписка:</b> {subs}\n"
            users_text += f"├ <b>Рефералы:</b> {refs}\n"
            users_text += f"└ <b>NFT:</b> {nft}\n\n"

        if len(users) > 20:
            users_text += f"\n📋 ... и еще {len(users) - 20} пользователей"

    await query.edit_message_text(
        users_text,
        reply_markup=get_admin_back_keyboard(),
        parse_mode='HTML'  # Используем HTML разметку
    )


async def admin_delete_user_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало процесса удаления пользователя"""
    query = update.callback_query
    user_id = query.from_user.id

    if not is_admin(user_id):
        await query.edit_message_text("❌ Доступ запрещен.")
        return

    delete_text = (
        "🗑️ **Удаление пользователя**\n\n"
        "Для удаления пользователя введите команду:\n"
        "`/delete_user USER_ID`\n\n"
        "Например: `/delete_user 123456789`\n\n"
        "⚠️ **Внимание:** Это действие нельзя отменить!"
    )

    await query.edit_message_text(
        delete_text,
        reply_markup=get_admin_back_keyboard(),
        parse_mode='Markdown'
    )


async def delete_user_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда для удаления пользователя"""
    user_id = update.effective_user.id

    if not is_admin(user_id):
        await update.message.reply_text("❌ Доступ запрещен.")
        return

    if not context.args:
        await update.message.reply_text(
            "❌ Использование: `/delete_user USER_ID`",
            parse_mode='Markdown'
        )
        return

    try:
        target_user_id = int(context.args[0])

        # Проверяем, существует ли пользователь
        user = get_user(target_user_id)
        if not user:
            await update.message.reply_text(f"❌ Пользователь с ID {target_user_id} не найден.")
            return

        # Удаляем пользователя
        delete_user(target_user_id)

        await update.message.reply_text(
            f"✅ Пользователь {target_user_id} успешно удален."
        )

        # Логируем действие
        logger.info(f"Админ {user_id} удалил пользователя {target_user_id}")

    except ValueError:
        await update.message.reply_text("❌ Неверный ID пользователя.")


# ========== ЗАПУСК БОТА ==========
def main():
    """Основная функция запуска бота"""
    init_db()

    application = Application.builder().token(BOT_TOKEN).build()

    # Добавляем обработчики команд
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("delete_user", delete_user_command))

    # Добавляем обработчик кнопок
    application.add_handler(CallbackQueryHandler(button_handler))

    logger.info("Бот запущен...")
    application.run_polling()


if __name__ == "__main__":
    main()